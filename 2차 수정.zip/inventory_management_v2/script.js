"use strict";

const PRODUCT_STORAGE_KEY = "inventoryProductsV2";
const CATEGORY_STORAGE_KEY = "inventoryCategoriesV2";

const DEFAULT_CATEGORIES = [
  { name: "식품", prefix: "F", description: "식품 및 음료" },
  { name: "사무용품", prefix: "O", description: "사무 및 문구용품" },
  { name: "생활용품", prefix: "L", description: "생활 관련 용품" },
  { name: "전자제품", prefix: "E", description: "전자 및 전기 제품" }
];

function getProducts() {
  const saved = localStorage.getItem(PRODUCT_STORAGE_KEY);
  if (saved === null) return [];
  try { return JSON.parse(saved); }
  catch (error) { console.error("상품 데이터 읽기 오류:", error); return []; }
}

function saveProducts(products) {
  localStorage.setItem(PRODUCT_STORAGE_KEY, JSON.stringify(products));
}

function getCategories() {
  const saved = localStorage.getItem(CATEGORY_STORAGE_KEY);
  if (saved === null) {
    saveCategories(DEFAULT_CATEGORIES);
    return [...DEFAULT_CATEGORIES];
  }
  try { return JSON.parse(saved); }
  catch (error) { console.error("분류 데이터 읽기 오류:", error); return []; }
}

function saveCategories(categories) {
  localStorage.setItem(CATEGORY_STORAGE_KEY, JSON.stringify(categories));
}

function findProductByCode(code) {
  return getProducts().find(product => product.code === code);
}

function findCategoryByPrefix(prefix) {
  return getCategories().find(category => category.prefix === prefix);
}

function openSubWindow(url, windowName, width = 600, height = 650) {
  const left = window.screenX + Math.max(0, (window.outerWidth - width) / 2);
  const top = window.screenY + Math.max(0, (window.outerHeight - height) / 2);
  const options = [
    `width=${width}`,
    `height=${height}`,
    `left=${Math.round(left)}`,
    `top=${Math.round(top)}`,
    "resizable=yes",
    "scrollbars=yes"
  ].join(",");
  const popup = window.open(url, windowName, options);
  if (popup) popup.focus();
  return popup;
}

function openMessageWindow(title, message, windowName = "inventoryMessageWindow") {
  const url = `message.html?title=${encodeURIComponent(title)}&message=${encodeURIComponent(message)}`;
  return openSubWindow(url, windowName, 450, 330);
}

function createProductCode(prefix) {
  const products = getProducts();
  let largestNumber = 0;
  products.forEach(product => {
    if (product.code.startsWith(prefix)) {
      const numberPart = Number(product.code.substring(prefix.length));
      if (Number.isInteger(numberPart) && numberPart > largestNumber) largestNumber = numberPart;
    }
  });
  return prefix + String(largestNumber + 1).padStart(4, "0");
}

function getProductStatus(product) {
  if (product.stock === 0) return { text: "품절", className: "status-out" };
  if (product.stock <= product.lowStockThreshold) return { text: "재고 부족", className: "status-low" };
  return { text: "정상", className: "status-normal" };
}

function createTableCell(text) {
  const cell = document.createElement("td");
  cell.textContent = text;
  return cell;
}

function initializeMainPage() {
  const tableBody = document.getElementById("productTableBody");
  if (!tableBody) return;

  document.getElementById("categoryManageButton").addEventListener("click", () => {
    openSubWindow("category-manage.html", "categoryManageWindow", 720, 760);
  });

  document.getElementById("addProductButton").addEventListener("click", () => {
    openSubWindow("add-product.html", "addProductWindow", 600, 720);
  });

  document.getElementById("deleteSelectedButton").addEventListener("click", () => {
    const checked = document.querySelectorAll(".product-checkbox:checked");
    if (checked.length === 0) {
      openMessageWindow("상품 삭제", "삭제할 상품을 선택해주세요.", "deleteWarningWindow");
      return;
    }
    const codes = Array.from(checked).map(box => box.value);
    openSubWindow(
      `delete-product.html?codes=${encodeURIComponent(codes.join(","))}`,
      "deleteProductWindow",
      540,
      520
    );
  });

  // CSV 관련 이벤트 연결 (가져오기 / 출력)
  document.getElementById("csvExportButton").addEventListener("click", exportProductsToCSV);
  const fileInput = document.getElementById("csvFileInput");
  document.getElementById("csvImportButton").addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", importProductsFromCSV);

  document.getElementById("searchButton").addEventListener("click", renderProductTable);
  document.getElementById("searchKeyword").addEventListener("keydown", event => {
    if (event.key === "Enter") renderProductTable();
  });

  document.getElementById("selectAllCheckbox").addEventListener("change", event => {
    document.querySelectorAll(".product-checkbox").forEach(box => {
      box.checked = event.target.checked;
    });
  });

  window.addEventListener("focus", renderProductTable);
  window.addEventListener("storage", event => {
    if (event.key === PRODUCT_STORAGE_KEY || event.key === CATEGORY_STORAGE_KEY) renderProductTable();
  });

  renderProductTable();
}

function renderProductTable() {
  const tableBody = document.getElementById("productTableBody");
  if (!tableBody) return;

  let products = getProducts();
  const keyword = document.getElementById("searchKeyword").value.trim().toLowerCase();
  const type = document.getElementById("searchType").value;

  if (keyword !== "") {
    products = products.filter(product => {
      let target = product.name;
      if (type === "code") target = product.code;
      if (type === "category") target = `${product.categoryName} ${product.categoryPrefix}`;
      return String(target).toLowerCase().includes(keyword);
    });
  }

  tableBody.innerHTML = "";
  document.getElementById("selectAllCheckbox").checked = false;
  document.getElementById("productCount").textContent = `총 ${products.length}개`;

  if (products.length === 0) {
    const row = document.createElement("tr");
    row.className = "empty-row";
    const cell = document.createElement("td");
    cell.colSpan = 7;
    cell.className = "empty-message";
    cell.textContent = keyword === "" ? "등록된 상품이 없습니다." : "검색 결과가 없습니다.";
    row.appendChild(cell);
    tableBody.appendChild(row);
    return;
  }

  products.forEach(product => {
    const row = document.createElement("tr");
    const checkCell = document.createElement("td");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "product-checkbox";
    checkbox.value = product.code;
    checkbox.addEventListener("click", event => event.stopPropagation());
    checkCell.appendChild(checkbox);

    const status = getProductStatus(product);
    const statusCell = createTableCell(status.text);
    statusCell.className = status.className;

    row.appendChild(checkCell);
    row.appendChild(createTableCell(product.code));
    row.appendChild(createTableCell(product.categoryName));
    row.appendChild(createTableCell(product.name));
    row.appendChild(createTableCell(product.stock.toLocaleString("ko-KR")));
    row.appendChild(createTableCell(product.price.toLocaleString("ko-KR") + "원"));
    row.appendChild(statusCell);

    row.addEventListener("click", () => {
      openSubWindow(
        `product-detail.html?code=${encodeURIComponent(product.code)}`,
        "productDetailWindow",
        560,
        590
      );
    });

    tableBody.appendChild(row);
  });
}

function initializeCategoryManagePage() {
  const tableBody = document.getElementById("categoryTableBody");
  if (!tableBody) return;

  const nameInput = document.getElementById("categoryName");
  const prefixInput = document.getElementById("categoryPrefix");
  const descriptionInput = document.getElementById("categoryDescription");

  prefixInput.addEventListener("input", () => {
    prefixInput.value = prefixInput.value.toUpperCase().replace(/[^A-Z]/g, "").slice(0, 1);
  });

  document.getElementById("confirmCategoryButton").addEventListener("click", () => {
    const name = nameInput.value.trim();
    const prefix = prefixInput.value.trim().toUpperCase();
    const description = descriptionInput.value.trim();

    if (name === "") return openMessageWindow("분류 입력 오류", "상품 분류명을 입력해주세요.", "categoryWarningWindow");
    if (!/^[A-Z]$/.test(prefix)) return openMessageWindow("분류 입력 오류", "상품 분류 코드는 영문 알파벳 1자리로 입력해주세요.", "categoryWarningWindow");
    if (description === "") return openMessageWindow("분류 입력 오류", "상품 분류 설명을 입력해주세요.", "categoryWarningWindow");

    const categories = getCategories();
    if (categories.some(category => category.name.toLowerCase() === name.toLowerCase())) {
      return openMessageWindow("분류 입력 오류", "이미 등록된 상품 분류명입니다.", "categoryWarningWindow");
    }
    if (categories.some(category => category.prefix === prefix)) {
      return openMessageWindow("분류 입력 오류", `분류 코드 ${prefix}는 이미 사용 중입니다.`, "categoryWarningWindow");
    }

    categories.push({ name, prefix, description });
    saveCategories(categories);
    renderCategoryTable();
    nameInput.value = "";
    prefixInput.value = "";
    descriptionInput.value = "";

    openMessageWindow(
      "상품 분류 추가 완료",
      `상품 분류 추가가 완료되었습니다.\n\n분류명: ${name}\n분류코드: ${prefix}`,
      "categorySuccessWindow"
    );
  });

  document.getElementById("cancelCategoryButton").addEventListener("click", () => window.close());
  renderCategoryTable();
}

function renderCategoryTable() {
  const tableBody = document.getElementById("categoryTableBody");
  if (!tableBody) return;
  const categories = getCategories();
  tableBody.innerHTML = "";

  if (categories.length === 0) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 3;
    cell.className = "category-empty";
    cell.textContent = "등록된 상품 분류가 없습니다.";
    row.appendChild(cell);
    tableBody.appendChild(row);
    return;
  }

  categories.forEach(category => {
    const row = document.createElement("tr");
    row.appendChild(createTableCell(category.name));
    row.appendChild(createTableCell(category.prefix));
    row.appendChild(createTableCell(category.description));
    tableBody.appendChild(row);
  });
}

function initializeAddProductPage() {
  const categorySelect = document.getElementById("addProductCategory");
  if (!categorySelect) return;
  loadCategoryOptions();

  document.getElementById("confirmAddButton").addEventListener("click", () => {
    const name = document.getElementById("addProductName").value.trim();
    const stockText = document.getElementById("addProductStock").value;
    const prefix = categorySelect.value;
    const thresholdText = document.getElementById("addLowStockThreshold").value;
    const priceText = document.getElementById("addProductPrice").value;

    if (name === "") return openMessageWindow("상품 입력 오류", "상품명을 입력해주세요.", "addProductWarningWindow");
    if (stockText === "") return openMessageWindow("상품 입력 오류", "상품 재고수량을 입력해주세요.", "addProductWarningWindow");
    if (prefix === "") return openMessageWindow("상품 입력 오류", "상품 분류를 선택해주세요.", "addProductWarningWindow");
    if (thresholdText === "") return openMessageWindow("상품 입력 오류", "재고 부족 기준수량을 입력해주세요.", "addProductWarningWindow");
    if (priceText === "") return openMessageWindow("상품 입력 오류", "상품 단가를 입력해주세요.", "addProductWarningWindow");

    const stock = Number(stockText);
    const threshold = Number(thresholdText);
    const price = Number(priceText);

    if (!Number.isInteger(stock) || stock < 0) return openMessageWindow("상품 입력 오류", "상품 재고수량은 0 이상의 정수로 입력해주세요.", "addProductWarningWindow");
    if (!Number.isInteger(threshold) || threshold < 0) return openMessageWindow("상품 입력 오류", "재고 부족 기준수량은 0 이상의 정수로 입력해주세요.", "addProductWarningWindow");
    if (!Number.isInteger(price) || price < 0) return openMessageWindow("상품 입력 오류", "상품 단가는 0 이상의 정수로 입력해주세요.", "addProductWarningWindow");

    const category = findCategoryByPrefix(prefix);
    if (!category) return openMessageWindow("상품 입력 오류", "선택한 상품 분류 정보를 찾을 수 없습니다.", "addProductWarningWindow");

    const productCode = createProductCode(prefix);
    const products = getProducts();
    products.push({
      code: productCode,
      name,
      categoryName: category.name,
      categoryPrefix: category.prefix,
      stock,
      lowStockThreshold: threshold,
      price
    });
    saveProducts(products);

    openMessageWindow(
      "상품 추가 완료",
      `상품이 목록에 추가되었습니다.\n\n상품명: ${name}\n상품코드: ${productCode}`,
      "addProductSuccessWindow"
    );
    window.close();
  });

  document.getElementById("cancelAddButton").addEventListener("click", () => window.close());
}

function loadCategoryOptions() {
  const select = document.getElementById("addProductCategory");
  if (!select) return;
  select.innerHTML = '<option value="">상품 분류를 선택하세요</option>';
  getCategories().forEach(category => {
    const option = document.createElement("option");
    option.value = category.prefix;
    option.textContent = `${category.name} (${category.prefix})`;
    select.appendChild(option);
  });
}

function initializeDeleteProductPage() {
  const deleteList = document.getElementById("deleteProductList");
  if (!deleteList) return;

  const params = new URLSearchParams(window.location.search);
  const selectedCodes = (params.get("codes") || "")
    .split(",")
    .map(code => code.trim())
    .filter(Boolean);

  const selectedProducts = getProducts().filter(product => selectedCodes.includes(product.code));
  deleteList.innerHTML = "";

  if (selectedProducts.length === 0) {
    deleteList.textContent = "선택된 상품이 없습니다.";
  } else {
    selectedProducts.forEach(product => {
      const line = document.createElement("p");
      line.textContent = `${product.code} - ${product.name}`;
      deleteList.appendChild(line);
    });
  }

  document.getElementById("confirmDeleteButton").addEventListener("click", () => {
    if (selectedProducts.length === 0) return openMessageWindow("상품 삭제", "삭제할 상품이 없습니다.", "deleteWarningWindow");

    const updatedProducts = getProducts().filter(product => !selectedCodes.includes(product.code));
    saveProducts(updatedProducts);
    const names = selectedProducts.map(product => product.name).join(", ");
    openMessageWindow("상품 삭제 완료", `상품 삭제가 완료되었습니다.\n\n상품명: ${names}`, "deleteSuccessWindow");
    window.close();
  });

  document.getElementById("cancelDeleteButton").addEventListener("click", () => window.close());
}

function initializeProductDetailPage() {
  if (!document.getElementById("detailProductName")) return;
  const productCode = new URLSearchParams(window.location.search).get("code");

  function refreshDetail() {
    const product = findProductByCode(productCode);
    if (!product) return openMessageWindow("상품 조회 오류", "상품 정보를 찾을 수 없습니다.", "detailWarningWindow");
    document.getElementById("detailProductName").textContent = product.name;
    document.getElementById("detailProductCode").textContent = product.code;
    document.getElementById("detailProductCategory").textContent = `${product.categoryName} (${product.categoryPrefix})`;
    document.getElementById("detailProductStock").textContent = product.stock.toLocaleString("ko-KR") + "개";
    document.getElementById("detailProductPrice").textContent = product.price.toLocaleString("ko-KR") + "원";
    document.getElementById("detailLowStockThreshold").textContent = product.lowStockThreshold.toLocaleString("ko-KR") + "개";
  }

  document.getElementById("stockInButton").addEventListener("click", () => {
    openSubWindow(`stock-in.html?code=${encodeURIComponent(productCode)}`, "stockInWindow", 520, 520);
  });

  document.getElementById("stockOutButton").addEventListener("click", () => {
    openSubWindow(`stock-out.html?code=${encodeURIComponent(productCode)}`, "stockOutWindow", 520, 520);
  });

  document.getElementById("closeDetailButton").addEventListener("click", () => window.close());
  window.addEventListener("focus", refreshDetail);
  refreshDetail();
}

function initializeStockInPage() {
  const quantityInput = document.getElementById("stockInQuantity");
  if (!quantityInput) return;

  const productCode = new URLSearchParams(window.location.search).get("code");
  const product = findProductByCode(productCode);
  if (!product) return openMessageWindow("입고 오류", "상품 정보를 찾을 수 없습니다.", "stockInWarningWindow");

  document.getElementById("stockInProductName").textContent = product.name;
  document.getElementById("stockInCurrentStock").textContent = product.stock;
  const afterStock = document.getElementById("stockInAfterStock");
  afterStock.textContent = product.stock;

  quantityInput.addEventListener("input", () => {
    const quantity = Number(quantityInput.value);
    afterStock.textContent = Number.isFinite(quantity) && quantity >= 0 ? product.stock + quantity : product.stock;
  });

  document.getElementById("confirmStockInButton").addEventListener("click", () => {
    const quantity = Number(quantityInput.value);
    if (!Number.isInteger(quantity) || quantity <= 0) return openMessageWindow("입고 오류", "입고 수량은 1 이상의 정수로 입력해주세요.", "stockInWarningWindow");

    const products = getProducts();
    const target = products.find(item => item.code === productCode);
    if (!target) return openMessageWindow("입고 오류", "상품 정보를 찾을 수 없습니다.", "stockInWarningWindow");

    target.stock += quantity;
    saveProducts(products);
    openMessageWindow("입고 완료", `${target.name} 상품 ${quantity}개가 입고되었습니다.\n\n입고 후 상품 개수: ${target.stock}개`, "stockInSuccessWindow");
    window.close();
  });

  document.getElementById("cancelStockInButton").addEventListener("click", () => window.close());
}

function initializeStockOutPage() {
  const quantityInput = document.getElementById("stockOutQuantity");
  if (!quantityInput) return;

  const productCode = new URLSearchParams(window.location.search).get("code");
  const product = findProductByCode(productCode);
  if (!product) return openMessageWindow("출고 오류", "상품 정보를 찾을 수 없습니다.", "stockOutWarningWindow");

  document.getElementById("stockOutProductName").textContent = product.name;
  document.getElementById("stockOutCurrentStock").textContent = product.stock;
  const afterStock = document.getElementById("stockOutAfterStock");
  afterStock.textContent = product.stock;

  quantityInput.addEventListener("input", () => {
    const quantity = Number(quantityInput.value);
    afterStock.textContent = Number.isFinite(quantity) && quantity >= 0 ? product.stock - quantity : product.stock;
  });

  document.getElementById("confirmStockOutButton").addEventListener("click", () => {
    const quantity = Number(quantityInput.value);
    if (!Number.isInteger(quantity) || quantity <= 0) return openMessageWindow("출고 오류", "출고 수량은 1 이상의 정수로 입력해주세요.", "stockOutWarningWindow");

    const products = getProducts();
    const target = products.find(item => item.code === productCode);
    if (!target) return openMessageWindow("출고 오류", "상품 정보를 찾을 수 없습니다.", "stockOutWarningWindow");
    if (quantity > target.stock) return openMessageWindow("출고 오류", `현재 재고는 ${target.stock}개입니다.\n현재 재고보다 많은 수량은 출고할 수 없습니다.`, "stockOutWarningWindow");

    target.stock -= quantity;
    saveProducts(products);
    openMessageWindow("출고 완료", `${target.name} 상품 ${quantity}개가 출고되었습니다.\n\n출고 후 상품 개수: ${target.stock}개`, "stockOutSuccessWindow");
    window.close();
  });

  document.getElementById("cancelStockOutButton").addEventListener("click", () => window.close());
}

function initializeMessagePage() {
  if (!document.getElementById("messageTitle")) return;
  const params = new URLSearchParams(window.location.search);
  document.getElementById("messageTitle").textContent = params.get("title") || "안내";
  document.getElementById("messageText").textContent = params.get("message") || "";
  document.getElementById("messageConfirmButton").addEventListener("click", () => window.close());
}

// AES-GCM 데이터 암호화
async function encryptData(plainText, password) {
  const enc = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));

  const passwordKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );

  const key = await crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    passwordKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt"]
  );

  const encryptedContent = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    enc.encode(plainText)
  );

  const combinedBuffer = new Uint8Array(salt.length + iv.length + encryptedContent.byteLength);
  combinedBuffer.set(salt, 0);
  combinedBuffer.set(iv, salt.length);
  combinedBuffer.set(new Uint8Array(encryptedContent), salt.length + iv.length);

  return combinedBuffer;
}

// AES-GCM 데이터 복호화
async function decryptData(combinedBuffer, password) {
  const dec = new TextDecoder();
  const salt = combinedBuffer.slice(0, 16);
  const iv = combinedBuffer.slice(16, 28);
  const data = combinedBuffer.slice(28);

  const passwordKey = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );

  const key = await crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    passwordKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["decrypt"]
  );

  const decryptedContent = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv },
    key,
    data
  );

  return dec.decode(decryptedContent);
}

// 비밀번호 기반 CSV 암호화 내보내기
async function exportProductsToCSV() {
  const products = getProducts();
  if (products.length === 0) return openMessageWindow("CSV 출력", "출력할 상품 데이터가 없습니다.", "csvWarningWindow");

  const password = prompt("파일을 암호화할 비밀번호를 입력해주세요:");
  if (password === null) return;
  if (password.trim() === "") {
    return openMessageWindow("CSV 출력 오류", "비밀번호를 입력해야 내보낼 수 있습니다.", "csvWarningWindow");
  }

  const rows = [["상품코드", "상품분류", "분류코드", "상품명", "재고수량", "상품단가", "재고부족기준", "상품상태"]];
  products.forEach(product => {
    rows.push([
      product.code,
      product.categoryName,
      product.categoryPrefix,
      product.name,
      product.stock,
      product.price,
      product.lowStockThreshold,
      getProductStatus(product).text
    ]);
  });

  const csvContent = rows.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n");

  try {
    const encryptedBuffer = await encryptData("\uFEFF" + csvContent, password);
    const blob = new Blob([encryptedBuffer], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "inventory_encrypted.enc";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error("암호화 내보내기 오류:", error);
    openMessageWindow("CSV 출력 오류", "파일 암호화 처리 중 오류가 발생했습니다.", "csvWarningWindow");
  }
}

// 암호화된 파일 불러오기(복호화 및 데이터 로드)
async function importProductsFromCSV(event) {
  const file = event.target.files[0];
  if (!file) return;

  const password = prompt("파일의 암호를 해독할 비밀번호를 입력하세요:");
  if (password === null) {
    event.target.value = "";
    return;
  }

  try {
    const arrayBuffer = await file.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    
    // 복호화 수행
    let textContent;
    try {
      textContent = await decryptData(uint8Array, password);
    } catch (e) {
      event.target.value = "";
      return openMessageWindow("가져오기 실패", "비밀번호가 일치하지 않거나 파일이 손상되었습니다.", "csvImportWarning");
    }

    // BOM 제거
    if (textContent.startsWith("\uFEFF")) {
      textContent = textContent.slice(1);
    }

    // CSV 파싱
    const lines = textContent.split(/\r?\n/).filter(line => line.trim() !== "");
    if (lines.length <= 1) {
      event.target.value = "";
      return openMessageWindow("가져오기 오류", "유효한 상품 데이터가 없습니다.", "csvImportWarning");
    }

    const importedProducts = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(",").map(val => val.replace(/^"|"$/g, "").replaceAll('""', '"'));
      if (cols.length >= 7) {
        importedProducts.push({
          code: cols[0],
          categoryName: cols[1],
          categoryPrefix: cols[2],
          name: cols[3],
          stock: Number(cols[4]) || 0,
          price: Number(cols[5]) || 0,
          lowStockThreshold: Number(cols[6]) || 0
        });
      }
    }

    if (importedProducts.length > 0) {
      saveProducts(importedProducts);
      renderProductTable();
      openMessageWindow("가져오기 완료", `총 ${importedProducts.length}개의 상품 데이터를 불러왔습니다.`, "csvImportSuccess");
    } else {
      openMessageWindow("가져오기 오류", "파싱할 수 있는 상품 데이터가 없습니다.", "csvImportWarning");
    }
  } catch (err) {
    console.error("파일 불러오기 오류:", err);
    openMessageWindow("가져오기 오류", "파일을 읽는 과정에서 오류가 발생했습니다.", "csvImportWarning");
  } finally {
    event.target.value = "";
  }
}

function initializeDashboardPage() {
  const kpiProductCount = document.getElementById("dashProductCount");
  if (!kpiProductCount) return;

  function renderDashboard() {
    const products = getProducts();

    const productCount = products.length;
    const totalStock = products.reduce((sum, product) => sum + product.stock, 0);
    const totalValue = products.reduce((sum, product) => sum + product.stock * product.price, 0);
    const lowStockProducts = products.filter(product => product.stock <= product.lowStockThreshold);

    kpiProductCount.textContent = `${productCount.toLocaleString("ko-KR")}개`;
    document.getElementById("dashTotalStock").textContent = `${totalStock.toLocaleString("ko-KR")}개`;
    document.getElementById("dashLowStockCount").textContent = `${lowStockProducts.length.toLocaleString("ko-KR")}개`;
    document.getElementById("dashTotalValue").textContent = `${totalValue.toLocaleString("ko-KR")}원`;

    const listEl = document.getElementById("dashLowStockList");
    listEl.innerHTML = "";

    if (lowStockProducts.length === 0) {
      const empty = document.createElement("p");
      empty.className = "dashboard-empty";
      empty.textContent = "재고가 부족한 상품이 없습니다.";
      listEl.appendChild(empty);
      return;
    }

    lowStockProducts.forEach(product => {
      const row = document.createElement("div");
      row.className = "dashboard-low-stock-item";

      const nameSpan = document.createElement("span");
      nameSpan.textContent = product.name;

      const amountSpan = document.createElement("span");
      amountSpan.className = "dashboard-low-stock-amount";
      amountSpan.textContent = `${product.stock}개 / 기준 ${product.lowStockThreshold}개`;

      row.appendChild(nameSpan);
      row.appendChild(amountSpan);
      listEl.appendChild(row);
    });
  }

  renderDashboard();

  // 상품현황(index.html)에서 데이터를 바꾸고 돌아왔을 때 최신 값으로 갱신
  window.addEventListener("focus", renderDashboard);
  // 다른 탭/팝업 창에서 상품·분류 데이터가 바뀌었을 때도 갱신
  window.addEventListener("storage", event => {
    if (event.key === PRODUCT_STORAGE_KEY || event.key === CATEGORY_STORAGE_KEY) renderDashboard();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  getCategories();
  initializeMainPage();
  initializeDashboardPage();
  initializeCategoryManagePage();
  initializeAddProductPage();
  initializeDeleteProductPage();
  initializeProductDetailPage();
  initializeStockInPage();
  initializeStockOutPage();
  initializeMessagePage();
});