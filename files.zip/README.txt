재고 관리 시스템 v2
====================

반영된 기능
- 대시보드 화면(dashboard.html): 상품 수 / 총 재고 / 부족 상품 / 총 재고자산 요약과
  재고 부족 상품 목록을 보여주고, "상품현황" 카드를 누르면 index.html(상품 목록)로 이동
- 메인 화면(index.html): 검색, 분류 관리, CSV 출력, 상품 추가/제거
- 검색: 상품명 / 상품코드 / 상품분류명 및 분류코드
- 체크박스: 개별 선택 / 전체 선택 / 다중 삭제
- 상품 행 클릭: 상품 상태창
- 분류 관리: 사용자 직접 분류명 + 알파벳 1자리 코드 + 설명 추가
- 기본 분류: 식품 F / 사무용품 O / 생활용품 L / 전자제품 E
- 신규 분류는 상품 추가창의 선택목록에 자동 반영
- 분류 코드 소문자 입력 시 대문자로 자동 변환
- 분류명/코드 중복 방지
- 상품코드 자동 생성: 예) C 분류 첫 상품은 C0001
- 상품 추가 완료 / 삭제 완료 / 분류 추가 완료 별도 확인창
- 입고/출고 별도 창
- 입고/출고 후 재고 자동 계산
- 현재 재고보다 많은 출고 차단
- 상품 상태: 정상 / 재고 부족 / 품절
- CSV 출력

실행 방법
1. VS Code에서 이 폴더를 엽니다.
2. Live Server 확장 프로그램을 설치합니다.
3. dashboard.html을 Open with Live Server로 실행합니다. (대시보드가 시작 화면)
4. 대시보드의 "상품현황" 카드를 누르면 index.html(상품 목록)로 이동합니다.

중요
- 여러 창이 같은 상품/분류 데이터를 공유하도록 현재는 localStorage를 사용합니다.
- 이것은 개발/테스트용 저장 방식입니다.
- 프로젝트 최종 단계에서 CSV 불러오기/저장 구조와 연결할 수 있습니다.

파일
- dashboard.html
- index.html
- category-manage.html
- add-product.html
- delete-product.html
- product-detail.html
- stock-in.html
- stock-out.html
- message.html
- style.css
- script.js
